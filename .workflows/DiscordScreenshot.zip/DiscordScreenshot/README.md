# DiscordScreenshot

Build the jar (no PC needed):
1. Create a new GitHub repo, upload ALL files from this zip (keep folders, incl. `.github`).
2. Open the repo > Actions > "Build plugin jar" > it runs automatically (or tap "Run workflow").
3. When green, open the run > Artifacts > download `DiscordScreenshot-jar` (unzip -> DiscordScreenshot.jar).

Use it:
1. Install the BlueMap plugin (web server on port 8100) and let it render your world.
2. Drop DiscordScreenshot.jar in `plugins/`, start the server once, edit
   `plugins/DiscordScreenshot/config.yml` (bot-token), restart.
3. Invite the bot with the `bot` + `applications.commands` scopes.
4. First start downloads Chromium (~150 MB). Linux hosts need Chromium's system libs
   (libnss3, libatk, libgbm...). Panels without root access may not be able to run it.
