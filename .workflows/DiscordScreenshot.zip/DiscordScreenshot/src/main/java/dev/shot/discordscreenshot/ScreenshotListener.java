package dev.shot.discordscreenshot;

import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.utils.FileUpload;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Objects;
import java.util.concurrent.CompletionException;
import java.util.regex.Pattern;

/** Handles /screenshot: validates input, builds the BlueMap URL, renders async, posts the PNG. */
public final class ScreenshotListener extends ListenerAdapter {

    private static final Pattern MAP_ID = Pattern.compile("[A-Za-z0-9_.\\-]{1,64}");

    private final JavaPlugin plugin;
    private final BrowserRenderer renderer;

    // Immutable snapshot of config values (safe to read from JDA threads).
    private final String allowedChannel, baseUrl, defaultWorld, template;
    private final double distance, rotation, tilt;

    public ScreenshotListener(JavaPlugin plugin, BrowserRenderer renderer) {
        this.plugin = plugin;
        this.renderer = renderer;
        var cfg = plugin.getConfig();
        this.allowedChannel = cfg.getString("allowed-channel-id", "").trim();
        String base = cfg.getString("bluemap-url", "http://localhost:8100").trim();
        this.baseUrl = base.endsWith("/") ? base.substring(0, base.length() - 1) : base;
        this.defaultWorld = cfg.getString("default-world", "world");
        this.template = cfg.getString("url-template",
                "{base}/#{map}:{x}:{y}:{z}:{distance}:{rotation}:{tilt}:0:0");
        this.distance = cfg.getDouble("camera-distance", 120);
        this.rotation = cfg.getDouble("camera-rotation", 0);
        this.tilt = cfg.getDouble("camera-tilt", 0.8);
    }

    @Override
    public void onSlashCommandInteraction(@NotNull SlashCommandInteractionEvent event) {
        if (!event.getName().equals("screenshot")) return;

        if (!allowedChannel.isEmpty() && !allowedChannel.equals(event.getChannel().getId())) {
            event.reply("Please use this command in <#" + allowedChannel + ">.").setEphemeral(true).queue();
            return;
        }

        double x = Objects.requireNonNull(event.getOption("x")).getAsDouble();
        double y = Objects.requireNonNull(event.getOption("y")).getAsDouble();
        double z = Objects.requireNonNull(event.getOption("z")).getAsDouble();
        String world = event.getOption("world") != null
                ? Objects.requireNonNull(event.getOption("world")).getAsString().trim()
                : defaultWorld;

        if (!validCoord(x, 30_000_000) || !validCoord(y, 4_096) || !validCoord(z, 30_000_000)) {
            event.reply("❌ Those coordinates are out of range.").setEphemeral(true).queue();
            return;
        }
        if (!MAP_ID.matcher(world).matches()) {
            event.reply("❌ Invalid world / map id.").setEphemeral(true).queue();
            return;
        }

        final String url = buildUrl(world, x, y, z);
        final String label = fmt(x) + ", " + fmt(y) + ", " + fmt(z) + " (" + world + ")";

        // a) Acknowledge instantly (Discord requires a reply within 3 seconds).
        event.reply("📸 Generating screenshot...").queue(hook ->
                // b-g) Browser work happens on the renderer's own thread, never the main server thread.
                renderer.screenshot(url).whenComplete((png, err) -> {
                    if (err != null) {
                        Throwable cause = (err instanceof CompletionException && err.getCause() != null)
                                ? err.getCause() : err;
                        if (!(cause instanceof BrowserRenderer.BusyException)) {
                            plugin.getLogger().warning("Screenshot failed: " + cause);
                        }
                        hook.editOriginal("❌ " + cause.getMessage()).queue();
                        return;
                    }
                    hook.sendMessage("📍 **" + label + "**")
                            .addFiles(FileUpload.fromData(png, "screenshot.png"))
                            .queue(m -> hook.deleteOriginal().queue(null, e -> { }));
                }));
    }

    private String buildUrl(String map, double x, double y, double z) {
        return template
                .replace("{base}", baseUrl)
                .replace("{map}", map)
                .replace("{x}", fmt(x))
                .replace("{y}", fmt(y))
                .replace("{z}", fmt(z))
                .replace("{distance}", fmt(distance))
                .replace("{rotation}", fmt(rotation))
                .replace("{tilt}", fmt(tilt));
    }

    private static boolean validCoord(double v, double max) {
        return Double.isFinite(v) && Math.abs(v) <= max;
    }

    private static String fmt(double v) {
        return BigDecimal.valueOf(v).setScale(2, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString();
    }
}
