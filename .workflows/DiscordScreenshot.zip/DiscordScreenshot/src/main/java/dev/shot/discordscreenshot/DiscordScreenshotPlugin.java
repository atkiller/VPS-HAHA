package dev.shot.discordscreenshot;

import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.interactions.commands.OptionType;
import net.dv8tion.jda.api.interactions.commands.build.Commands;
import net.dv8tion.jda.api.interactions.commands.build.OptionData;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.time.Duration;
import java.util.Collections;
import java.util.logging.Level;

/**
 * Entry point: reads config.yml, boots the embedded Discord bot (off the main thread)
 * and registers the /screenshot slash command.
 */
public final class DiscordScreenshotPlugin extends JavaPlugin {

    private volatile JDA jda;
    private volatile boolean disabling;
    private BrowserRenderer renderer;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        FileConfiguration cfg = getConfig();

        String token = cfg.getString("bot-token", "").trim();
        if (token.isEmpty() || token.equals("PASTE_TOKEN_HERE")) {
            getLogger().severe("No bot token set. Put your Discord bot token in plugins/DiscordScreenshot/config.yml and restart.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        String method = cfg.getString("render-method", "BLUEMAP");
        if (!"BLUEMAP".equalsIgnoreCase(method)) {
            getLogger().warning("render-method '" + method + "' is not supported; using BLUEMAP.");
        }

        renderer = new BrowserRenderer(this);
        renderer.warmUp(); // downloads Chromium on first run, in the background

        // Never block the main server thread with network I/O.
        getServer().getScheduler().runTaskAsynchronously(this, () -> startBot(token));
    }

    private void startBot(String token) {
        try {
            JDA built = JDABuilder.createLight(token, Collections.emptyList())
                    .addEventListeners(new ScreenshotListener(this, renderer))
                    .build();
            built.awaitReady();

            if (disabling) { // plugin was disabled while we were logging in
                built.shutdownNow();
                return;
            }

            String defaultWorld = getConfig().getString("default-world", "world");
            built.updateCommands().addCommands(
                    Commands.slash("screenshot", "Render a 3D snapshot of a location in the world")
                            .addOptions(
                                    new OptionData(OptionType.NUMBER, "x", "X coordinate", true),
                                    new OptionData(OptionType.NUMBER, "y", "Y coordinate", true),
                                    new OptionData(OptionType.NUMBER, "z", "Z coordinate", true),
                                    new OptionData(OptionType.STRING, "world",
                                            "BlueMap map id (default: " + defaultWorld + ")", false))
            ).queue();

            this.jda = built;
            getLogger().info("Discord bot online as " + built.getSelfUser().getAsTag());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "Could not start the Discord bot (check bot-token).", e);
        }
    }

    @Override
    public void onDisable() {
        disabling = true;
        JDA j = jda;
        if (j != null) {
            j.shutdown();
            try {
                if (!j.awaitShutdown(Duration.ofSeconds(5))) j.shutdownNow();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                j.shutdownNow();
            }
        }
        if (renderer != null) renderer.shutdown();
    }
}
