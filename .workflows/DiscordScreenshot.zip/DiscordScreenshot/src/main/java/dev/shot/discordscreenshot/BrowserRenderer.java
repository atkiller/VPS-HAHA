package dev.shot.discordscreenshot;

import com.microsoft.playwright.*;
import com.microsoft.playwright.options.ScreenshotType;
import com.microsoft.playwright.options.WaitUntilState;
import org.bukkit.plugin.java.JavaPlugin;

import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;
import java.util.logging.Level;

/**
 * Owns the headless Chromium. Playwright objects are bound to the thread that created them,
 * so ALL browser work runs on one dedicated single-thread executor. A small bounded queue
 * protects the host from being flooded with requests.
 */
public final class BrowserRenderer {

    /** Thrown when too many screenshots are already queued. */
    public static final class BusyException extends RuntimeException {
        public BusyException() { super("The renderer is busy, try again in a moment."); }
    }

    private final JavaPlugin plugin;
    private final ThreadPoolExecutor executor;
    private final int width, height, waitMs, timeoutMs;
    private final Path browsersDir;

    // Only touched from the executor thread.
    private Playwright playwright;
    private Browser browser;

    public BrowserRenderer(JavaPlugin plugin) {
        this.plugin = plugin;
        var cfg = plugin.getConfig();
        this.width = cfg.getInt("viewport-width", 1280);
        this.height = cfg.getInt("viewport-height", 720);
        this.waitMs = cfg.getInt("render-wait-ms", 3000);
        this.timeoutMs = cfg.getInt("page-timeout-ms", 30000);
        this.browsersDir = plugin.getDataFolder().toPath().toAbsolutePath().resolve("browsers");

        ThreadFactory tf = r -> {
            Thread t = new Thread(r, "DiscordScreenshot-Browser");
            t.setDaemon(true);
            return t;
        };
        this.executor = new ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS,
                new ArrayBlockingQueue<>(4), tf, new ThreadPoolExecutor.AbortPolicy());
    }

    /** Starts the browser in the background so the first /screenshot is fast. */
    public void warmUp() {
        try {
            executor.execute(() -> {
                try {
                    plugin.getLogger().info("Preparing headless Chromium (first run downloads ~150 MB)...");
                    ensureBrowser();
                    plugin.getLogger().info("Headless browser ready.");
                } catch (Throwable t) {
                    plugin.getLogger().log(Level.SEVERE, "Headless browser setup failed", t);
                }
            });
        } catch (RejectedExecutionException ignored) { }
    }

    /** Asynchronously renders the URL and completes with PNG bytes. */
    public CompletableFuture<byte[]> screenshot(String url) {
        try {
            return CompletableFuture.supplyAsync(() -> render(url), executor);
        } catch (RejectedExecutionException e) {
            return CompletableFuture.failedFuture(new BusyException());
        }
    }

    private byte[] render(String url) {
        try {
            ensureBrowser();
            // A fresh context per request = clean state; closed automatically afterwards.
            try (BrowserContext ctx = browser.newContext(
                    new Browser.NewContextOptions().setViewportSize(width, height))) {
                Page page = ctx.newPage();
                page.navigate(url, new Page.NavigateOptions()
                        .setWaitUntil(WaitUntilState.LOAD).setTimeout(timeoutMs));
                try {
                    page.waitForSelector("canvas", new Page.WaitForSelectorOptions().setTimeout(timeoutMs));
                } catch (TimeoutError ignored) { /* screenshot whatever is there */ }
                page.waitForTimeout(waitMs); // let map tiles stream in
                return page.screenshot(new Page.ScreenshotOptions().setType(ScreenshotType.PNG));
            }
        } catch (PlaywrightException e) {
            closeBrowserQuietly(); // force a clean relaunch next time
            throw new IllegalStateException("Rendering failed: " + firstLine(e.getMessage()), e);
        }
    }

    private void ensureBrowser() {
        if (browser != null && browser.isConnected()) return;
        closeBrowserQuietly();
        if (playwright == null) {
            Map<String, String> env = new HashMap<>();
            env.put("PLAYWRIGHT_BROWSERS_PATH", browsersDir.toString());
            playwright = Playwright.create(new Playwright.CreateOptions().setEnv(env));
        }
        browser = playwright.chromium().launch(new BrowserType.LaunchOptions()
                .setHeadless(true)
                .setArgs(List.of(
                        "--no-sandbox",
                        "--disable-dev-shm-usage",
                        "--ignore-gpu-blocklist",
                        "--enable-webgl",
                        "--use-gl=angle",
                        "--use-angle=swiftshader",       // software WebGL: no GPU needed
                        "--enable-unsafe-swiftshader")));
    }

    private void closeBrowserQuietly() {
        try { if (browser != null) browser.close(); } catch (Exception ignored) { }
        browser = null;
    }

    private void closeAll() {
        closeBrowserQuietly();
        try { if (playwright != null) playwright.close(); } catch (Exception ignored) { }
        playwright = null;
    }

    /** Cleans up the browser and stops the worker thread. */
    public void shutdown() {
        try {
            executor.submit(this::closeAll).get(10, TimeUnit.SECONDS);
        } catch (Exception ignored) { }
        executor.shutdownNow();
    }

    private static String firstLine(String s) {
        if (s == null) return "unknown error";
        int i = s.indexOf('\n');
        return i > 0 ? s.substring(0, i) : s;
    }
}
